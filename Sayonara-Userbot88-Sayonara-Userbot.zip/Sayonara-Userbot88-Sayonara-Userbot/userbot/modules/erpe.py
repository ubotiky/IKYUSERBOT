# import by skyzo
# From Flicks Userbot
# Do not delete credits ⚠️

from time import sleep

from userbot import CMD_HELP
from userbot.events import register


@register(outgoing=True, pattern="^.adaerpe(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("**ER ERRR ERRPE ASUU WOKWOK KANG PAKE PP ORANG KOREA**")
    await typew.edit("`🏃.....ERPE KOMTOL.......🏃`")
    await typew.edit("`🏃....................🏃`")
    await typew.edit("`🏃..................🏃`")
    await typew.edit("`🏃.....`LARII`....🏃`")
    await typew.edit("`🏃..............🏃`")
    await typew.edit("`🏃.............🏃`")
    await typew.edit("`🏃..Anjing...🏃`")
    await typew.edit("`🏃.........🏃`")
    await typew.edit("`🏃..Erpa..🏃`")
    await typew.edit("`🏃...Erpe...🏃`")
    await typew.edit("`🏃....Cringe..🏃`")
    await typew.edit("`🏃....Tolol.....🏃`")
    await typew.edit("`🏃............🏃`")
    await typew.edit("`🏃..Tolong..🏃`")
    await typew.edit("`🏃...........🏃`")
    await typew.edit("`🏃............🏃`")
    await typew.edit("`🏃.............🏃`")
    await typew.edit("`🏃....Teyunkk...🏃`")
    await typew.edit("`🏃.....Kejar.....🏃`")
    await typew.edit("`🏃.....Sampai.....🏃`")
    await typew.edit("`🏃.....Dapat.......🏃`")
    await typew.edit("`🏃..................🏃`")
    await typew.edit("`🏃......Anjir........🏃`")
    await typew.edit("`🏃....................🏃`")
    await typew.edit("`🏃.....................🏃`")
    await typew.edit("`🏃..Huh-Huh-Huh.......🏃`")
    await typew.edit("`🏃...................🏃`")
    await typew.edit("`🏃..................🏃`")
    await typew.edit("`🏃.....Anak........🏃`")
    await typew.edit("`🏃................🏃`")
    await typew.edit("`🏃....Teyunkk....🏃`")
    await typew.edit("`🏃..............🏃`")
    await typew.edit("`🏃.............🏃`")
    await typew.edit("`🏃..Jungkok Teyunk..🏃`")
    await typew.edit("`🏃...........🏃`")
    await typew.edit("`🏃..........🏃`")
    await typew.edit("`🏃.........🏃`")
    await typew.edit("__KOK MAKIN DEKET SI.__")
    sleep(1)
    await typew.edit("`🏃.......🏃`")
    await typew.edit("`🏃...Taehyung..🏃`")
    await typew.edit("`🏃.....🏃`")
    await typew.edit("`🏃....🏃`")
    await typew.edit("**Untung Ngga Kena Njir**")
    sleep(1)
    await typew.edit("__Cape Juga Asu Cringe Gitu__")
    sleep(2)
    await typew.edit("**Kasian Erpe Awokawokawok Makanya Jan Pake PP Orang KOREA**")


@register(outgoing=True, pattern="^.erpe2(?: |$)(.*)")
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("HA ADA ERPE??")
    await typew.edit("HAHA")
    await typew.edit("HAHAHA")
    await typew.edit("HAHAHAHA")
    await typew.edit("HAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHA")
    await typew.edit("HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHA")


CMD_HELP.update(
    {
        "erpe": "**Modules** - `erpe`\
        \n\n Cmd : `.adaerpe`\
        \nUsage : ngatain anak erpe\
        \n\n Cmd : `.erpe2`\
        \nUsage : ngetawain anak erpe\
    "
    }
)
