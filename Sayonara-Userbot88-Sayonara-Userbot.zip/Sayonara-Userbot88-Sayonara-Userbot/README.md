<h1 align="center"><imgsrc="./resources/extras/geez.gif" width="35px">🔥SAYONARA-USERBOT🔥<imgsrc="./resources/extras/geez.gif" width="35px"></h1>
</p>
<p align="center">
    <a href="https://github.com/Krisnadiwangga/Sayonara-Userbot"> <img src="https://img.shields.io/github/repo-size/noob-kittu/YoneRobot?color=orange&logo=github&logoColor=green&style=for-the-badge" /></a>
    <a href="https://github.com/Krisnadiwangga/Sayonara-Userbot/commits"> <img src="https://img.shields.io/github/last-commit/noob-kittu/YoneRobot?color=blue&logo=github&logoColor=green&style=for-the-badge" /></a>
    <a href="https://github.com/Krisnadiwangga/Sayonara-Userbot/issues"> <img src="https://img.shields.io/github/issues/noob-kittu/YoneRobot?color=blueviolet&logo=github&logoColor=green&style=for-the-badge" /></a>
    <a href="https://github.com/Krisnadiwangga/Sayonara-Userbot/network/members"> <img src="https://img.shields.io/github/forks/noob-kittu/YoneRobot?color=red&logo=github&logoColor=green&style=for-the-badge" /></a>  
    <a href="https://pypi.org/project/Telethon/"> <img src="https://img.shields.io/pypi/v/telethon?color=yellow&label=telethon&logo=python&logoColor=green&style=for-the-badge" /></a>
</p>




![VIEWS](https://komarev.com/ghpvc/?username=Krisnadiwangga)
<a href="https://t.me/SayonaraSupport"><img src="https://img.shields.io/badge/KODE%20PENILAIAN-A+-blue.svg?style=for-the-badge&logo=Factor.">
  [![GitHub issues](https://img.shields.io/github/issues/Krisnadiwangga/Sayonara-Userbot?&style=plastic&logo=github)](https://github.com/Krisnadiwangga/Sayonara-Userbot/issues)
[![GitHub commit activity](https://img.shields.io/github/commit-activity/m/Krisnadiwangga/Sayonara-Userbot?&style=plastic&logo=github)](https://github.com/Krisnadiwangga/Sayonara-Userbot/graphs/commit-activity)
[![GitHub contributors](https://img.shields.io/github/contributors/Randi356/VEGETA-USERBOT?&style=plastic&logo=github)](https://GitHub.com/Krisnadiwangga/Sayonara-Userbot/graphs/contributors/)

<p align="center">

[<img src="https://telegra.ph/file/e5d4da833c5f47c1682bb.jpg">](https://t.me/NaraXmusic) 
  
#### JOIN YA KE SAYONARA SUPPORT!!

<a href="https://t.me/SayonaraSupport"><img src="https://img.shields.io/badge/Channel%20SAYONARA%20SUPPORT-red.svg?style=for-the-badge&logo=Telegram"></a>
<a href="https://t.me/SayonaraUpdate"><img src="https://img.shields.io/badge/Join-SAYONARA%20UPDATE-purple.svg?style=for-the-badge&logo=Telegram"></a>


### AMBIL STRING DI BAWAH INI:

##
[![SAYONARA-USERBOT-STRING](https://replit.com/badge/github/@ramadhani892/RAM-UBOT)](https://replit.com/@Randi356/StringSession-1#main.py)
##
  
  # Heroku
  <h3 align="center">Klik Tombol di Bawah ini untuk Deploy di Heroku :</h3>
  <p align="center"><a href="https://heroku.com/deploy?template=https://github.com/krisnadiwangga/Sayonara-userbot88/"> <img src="https://img.shields.io/badge/Deploy%20Ke%20Heroku-black?style=flat&logo=heroku" width="150" height="30.00" /></a></p>
  

<br>
</p>
  
  
  # MODULES PLUGINS UPDATES🌹
```
`HOW TO ADD MODULES PLUGIN COMMAD`

@register(outgoing=True, pattern='^.hello(?: |$)(.*)')
async def typewriter(typew):
typew.pattern_match.group(1)
await typew.edit("**hello.**")
```  

## Credit
TERIMAKASIH UNTUK😎

*   [LANDAK RAMA](https://github.com/ramadhani892/RAM-UBOT) - RAM-UBOT
*   [RENDY](https://github.com/Randi356/Vegeta-Userbot) - VEGETA-USERBOT
*   [SAYONARA](https://github.com/krisnadiwangga/Sayonara-Userbot04) - SAYONARA-USERBOT
 
# Userbot🔥
* - JANGAN LUPA KLICK STARS 🤗
